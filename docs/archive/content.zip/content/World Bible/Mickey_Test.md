# Mickey
A cynical detective who hates the rain. He trusts no one except his cat, Luna.